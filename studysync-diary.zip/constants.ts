
export const SUBJECTS = [
  "Math",
  "Physics",
  "Chemistry",
  "Biology",
  "Computer Science",
  "English",
  "Bengali",
  "History",
  "Geography",
  "Other",
];

export const TIME_SLOTS = [
  "Morning",
  "Noon",
  "Afternoon",
  "Evening",
  "Night",
];
